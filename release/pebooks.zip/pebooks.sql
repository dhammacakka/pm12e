INSERT INTO category (id, name, basket)
VALUES
('annya_nucat', 'nucat', 'annya');

INSERT INTO books (id, basket, category, name, firstpage, lastpage, pagecount, toc)
VALUES
('annya_nucat_book_1', 'annya', 'annya_nucat', 'nucat book 1', 1, 20, 20,
'subhead->intro->1
chapter->1. chapter 1->3
subhead->section 1.1->1
subhead->section 1.2->1
subhead->section 1.3->1
chapter->2. chapter 2->9
subhead->section 2.1->1
subhead->section 2.2->2
subhead->section 2.3->1
subhead->section 2.4->3');

INSERT INTO tocs (book_id, name, type, page_number)
VALUES
('annya_nucat_book_1', 'intro', 'subhead', 1),
('annya_nucat_book_1', 'chapter 1', 'chapter', 3),
('annya_nucat_book_1', 'section 1.1', 'subhead', 1),
('annya_nucat_book_1', 'section 1.2', 'subhead', 1),
('annya_nucat_book_1', 'section 1.3', 'subhead', 1),
('annya_nucat_book_1', 'chapter 2', 'chapter', 9),
('annya_nucat_book_1', 'section 2.1', 'subhead', 1),
('annya_nucat_book_1', 'section 2.2', 'subhead', 2),
('annya_nucat_book_1', 'section 2.3', 'subhead', 1),
('annya_nucat_book_1', 'section 2.4', 'subhead', 3);

INSERT INTO pages (bookid, page, content, paranum)
VALUES
  ('annya_nucat_book_1', 1, '<p class="centered">namo tassa bhagavato arahato sammāsambuddhassa</p>
    <p class="book">nucat book 1</p>
    <p class="subhead">book subhead</p>', '-1-'),
  ('annya_nucat_book_1', 2, '<p class="chapter">chapter 1</p>
    <p class="bodytext">bodytext content</p>', '-1-'),
  ('annya_nucat_book_1', 3, '<p class="gatha1">gatha1 style</p>', '-1-'),
  ('annya_nucat_book_1', 4, '<p class="gathalast">gathalast style</p>', '-1-'),
  ('annya_nucat_book_1', 5, '<p class="bodytext">bodytext style</p>
    <span class="bld">bld style</span>', '-1-'),
  ('annya_nucat_book_1', 6, '<p class="chapter">chapter 2</p>
    <p class="bodytext">bodytext content</p>', '-1-'),
  ('annya_nucat_book_1', 7, '<p class="gatha1">gatha1 style</p>', '-1-'),
  ('annya_nucat_book_1', 8, '<p class="gathalast">gathalast style</p>', '-1-'),
  ('annya_nucat_book_1', 9, '<p class="bodytext">bodytext style</p>
    <span class="bld">bld style</span>', '-1-'),
  ('annya_nucat_book_1', 10, '<p class="bodytext">bodytext</p>', '-1-');
